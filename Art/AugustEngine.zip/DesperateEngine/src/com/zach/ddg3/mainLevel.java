package com.zach.ddg3;

import com.zach.engine.Main;

public class mainLevel extends GameLevel
{
    @Override
    public void init(Main main)
    {

    }

    @Override
    public void update(Main main, float dt)
    {

    }

    @Override
    public void uninit()
    {

    }
}
